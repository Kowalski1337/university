package expression;

public interface Expression {
    void write(StringBuilder sb);
}
